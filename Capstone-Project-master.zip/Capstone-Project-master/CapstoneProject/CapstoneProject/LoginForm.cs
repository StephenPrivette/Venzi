﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapstoneProject
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void loginButton_Click(object sender, EventArgs e)
        {
            // if username matches database
            // if password matches database
            // else message box "doesn't match"
            // implement through ProgramManaer.instance

            bool validAccount = false;

            string username = userTextBox.Text;
            string password = passwordTextBox.Text;

            validAccount = SQLiteDataAccess.LoadUsers(username, password);

            if(validAccount == true)
            {
                MessageBox.Show("Login successful");
            }
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
