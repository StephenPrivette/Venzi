﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapstoneProject
{
    class SQLiteDataAccess
    {
        // Method for saving a user's data to the database
        public static void saveUser(string username, string password)
        {
            using (SQLiteConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                string sql = "Insert into Users (username, password) values(@param1, @param2)";


                cnn.Open();
                // Sends the data to be stored in the database
                using (SQLiteCommand cmd = new SQLiteCommand(sql, cnn))
                {
                    cmd.Parameters.Add(new SQLiteParameter("@param1", username));
                    cmd.Parameters.Add(new SQLiteParameter("@param2", password));
                    cmd.ExecuteNonQuery();
                }

                cnn.Close();
            }
        }

        // Method for loading a user from the database
        public static bool LoadUsers(string username, string password)
        {
            using (SQLiteConnection cnn = new SQLiteConnection(LoadConnectionString()))
            {
                bool validAccount = false;
                string usernameDB = "";
                string passwordDB = "";

                cnn.Open();

                SQLiteCommand command = cnn.CreateCommand();

                // Loads the record from the database that has a matching username
                command.CommandText = "select * from Users Where username Like @param1";
                command.Parameters.Add(new SQLiteParameter("@param1", username));
                command.Parameters.Add(new SQLiteParameter("@param2", password));

                // Runs command that reads the rows in the database
                SQLiteDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    usernameDB = reader.GetString(1);
                    passwordDB = reader.GetString(2);
                }


                reader.Close();
                cnn.Close();
                
                // Checks to see if the username and password have a match in the database before user can login
                if(username == usernameDB && passwordDB == password && password != "" && username != "")
                {
                    validAccount = true;
                    return validAccount;
                }
            }

            return false;

        }


        // Method for creating the string that allows the program to interact with the database
        public static string LoadConnectionString(string id = "Default")
        {
            return ConfigurationManager.ConnectionStrings[id].ConnectionString;
        }
    }
}
